package ng.com.soh.tailor.ms;

/**
 * Created by Blurryface on 10/26/17.
 */
public class AppConfig {
}

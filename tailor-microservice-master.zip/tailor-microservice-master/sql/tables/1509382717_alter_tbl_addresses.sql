ALTER TABLE `native_fittings_test`.`addresses`
ADD COLUMN `city` VARCHAR(20) NOT NULL AFTER `address`;
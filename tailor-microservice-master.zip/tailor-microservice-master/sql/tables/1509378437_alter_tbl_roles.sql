ALTER TABLE `native_fittings_test`.`roles`
ADD UNIQUE INDEX `name_UNIQUE` (`name` ASC);

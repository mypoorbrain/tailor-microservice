ALTER TABLE `native_fittings`.`permissions`
ADD UNIQUE INDEX `name_UNIQUE` (`name` ASC);
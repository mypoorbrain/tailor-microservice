ALTER TABLE `native_fittings_test`.`countries`
ADD UNIQUE INDEX `name_UNIQUE` (`name` ASC);
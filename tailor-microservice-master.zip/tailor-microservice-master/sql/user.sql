grant all privileges on native_fittings.* to 'sohsoft'@'localhost' identified by 'Password1$';
flush privileges;